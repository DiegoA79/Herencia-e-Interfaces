package figuraplana;

public interface FiguraPlana {
    double calcularArea();
    double calcularPerimetro();
}