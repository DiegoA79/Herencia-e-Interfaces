package figuraplana;

public abstract class Figura2D implements FiguraPlana {
    public abstract String imprimeFigura();
}